Short instructions:

	make to build it

	make test to test with the input1.txt file

	main is the executable

Some notes:

There is something weird going on with the order that I find unmarked states,
so it will not always go through them in the order they were added.  This
means that some of my final states will have different final names than the
example.  As far as I can tell, it still works, and the names are totally
arbitrary.  However, it will likely not match exactly what you are expecting
using the executable provided by Dr. Kulkarni.  FYI.

